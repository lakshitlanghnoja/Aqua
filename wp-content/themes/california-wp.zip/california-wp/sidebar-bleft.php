    <aside class="col-md-3 sidebar leftside">
     <?php
			dynamic_sidebar( 'Left Sidebar' );
     	
     ?>
    </aside>
    <!-- end-sidebar-->