<?php
/*
vc_map( array(
        'name' =>'WFlexSlider',
        'base' => 'flexslider',
        'category' => __( 'Webnus Shortcodes', 'WEBNUS_TEXT_DOMAIN' ),
        'show_settings_on_create'=>false,
		'params'=>array(
					array(
							'type' => 'textarea',
							'heading' => __( 'FlexSlider', 'WEBNUS_TEXT_DOMAIN' ),
							'param_name' => 'content',
							'value' => '[flexitem img="" alt=""][flexitem img="" alt=""]',
							'description' => __( 'FlexSlider Slides, [flexitem] Acceptable', 'WEBNUS_TEXT_DOMAIN')
					),
		)
        
    ) );

*/
?>