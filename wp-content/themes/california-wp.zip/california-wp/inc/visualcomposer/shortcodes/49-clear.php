<?php

vc_map( array(
        'name' =>'Webnus Clear',
        'base' => 'clear',
		"description" => "Clear fix",
        'show_settings_on_create'=>false,
        "icon" => "webnus_clear",
        'category' => __( 'Webnus Shortcodes', 'WEBNUS_TEXT_DOMAIN' ),
    ) );


?>