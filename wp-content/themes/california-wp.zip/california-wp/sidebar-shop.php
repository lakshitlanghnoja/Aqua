<?php
	echo '<aside id="sidebar_right" class="col-md-3 col-md-offset-1 sidebar">'; 
?>

	<div id="default-widget-area" class="widget-area">
		<ul class="xoxo">
			<?php dynamic_sidebar( 'shop-widget-area' ); ?>
		</ul>
	</div>
</aside>