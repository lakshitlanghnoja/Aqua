<div class="col-md-12">
<?php dynamic_sidebar('footer-section-1'); ?>
</div>